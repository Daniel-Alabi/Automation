# Forge

An MCP server for **generative 3D modeling** in Blender.

Most Blender MCP servers are a thin wrapper around "run this Python in Blender."
That works, but it makes the model a blind code generator: it writes `bpy` calls,
gets back `None`, and has no idea whether the result looks like anything. Forge is
built around the opposite assumption — that generative modeling is a *feedback
loop*, so the tool surface is shaped for build → look → correct.

Three design choices follow from that:

- **`render_view` returns an actual image.** The model sees its own geometry and can
  judge proportion, silhouette and material response instead of guessing.
- **Semantic face selection.** `edit_mesh` takes selectors like
  `{"axis": "+Z"}` or `{"largest": 3}`, so the model can say "extrude the top faces"
  without first solving for face indices it cannot see.
- **Checkpoint / rollback.** Generative modeling is mostly failed branches. Marking
  state before a risky sequence makes the failures cheap.

`run_python` is still there as an escape hatch for curves, geometry nodes, UVs and
anything else the typed tools do not reach.

---

## Architecture

```
MCP client  ──stdio──▶  server.py  ──TCP 9876──▶  addon.py  ──▶  bpy
(Claude etc.)          (this package)            (inside Blender)
```

Blender's Python API is not thread-safe, so the add-on runs a socket listener on a
background thread that only *queues* work. A `bpy.app.timers` callback drains that
queue on the main thread, executes the command, and hands the result back. The wire
protocol is newline-delimited JSON in both directions.

---

## Install

**1. The Blender add-on**

Edit → Preferences → Add-ons → Install from Disk → pick `addon.py` → enable
**Forge MCP Bridge**. Then in the 3D viewport press <kbd>N</kbd>, open the **Forge**
tab, and click **Start**. It listens on `127.0.0.1:9876`.

**2. The MCP server**

```bash
pip install -e .        # or: uv pip install -e .
```

**3. Register it with your MCP client**

```json
{
  "mcpServers": {
    "forge": {
      "command": "forge-mcp",
      "env": { "FORGE_BLENDER_PORT": "9876" }
    }
  }
}
```

If `forge-mcp` is not on your client's PATH, use the absolute path to the console
script, or `"command": "python", "args": ["-m", "forge_mcp.server"]`. Config file
locations differ per client — see your client's MCP docs
(for Claude Code: https://docs.claude.com/en/docs/claude-code/overview).

Environment variables: `FORGE_BLENDER_HOST`, `FORGE_BLENDER_PORT`, `FORGE_TIMEOUT`.

---

## Tools

| | |
|---|---|
| **Inspect** | `get_scene`, `inspect_object` |
| **Create** | `create_primitive`, `duplicate_object`, `delete_object`, `clear_scene` |
| **Shape** | `edit_mesh`, `add_modifier`, `apply_modifier`, `boolean`, `transform_object` |
| **Shade** | `create_material`, `assign_material`, `add_light`, `setup_camera`, `set_world` |
| **Feedback** | `render_view` → image |
| **Iterate** | `checkpoint`, `rollback`, `run_python`, `save_file` |

There is also a `model` prompt that seeds a blockout → refine → shade → render
workflow for a given subject.

### `edit_mesh` selectors

```python
"all"
{"axis": "+Z", "threshold": 0.5}   # faces whose normal points that way
{"above_z": 1.2}  /  {"below_z": 0}
{"largest": 3}
{"indices": [0, 4, 9]}
```

### `add_modifier` self-description

Every `add_modifier` response includes the modifier's full list of settable
properties. When a parameter silently does not apply, the model can read that list
and correct itself rather than guessing at the Blender API.

---

## Security

Forge executes model-generated Python inside Blender with no sandbox. That code can
read, write and delete files with the permissions of the Blender process. Blender's
own MCP server carries the same warning. Run it against work you have backed up, or
in a VM if the machine holds anything sensitive.

The listener binds to `127.0.0.1` only. Do not expose the port.

---

## Extending

Add a handler in `addon.py`, register it in `HANDLERS`, then add a typed wrapper in
`server.py`. The wrapper's docstring is what the model actually reads, so spend the
effort there — say when to use the tool and what good parameter values look like,
not just what the arguments are named.
