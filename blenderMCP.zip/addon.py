bl_info = {
    "name": "Forge MCP Bridge",
    "author": "Daniel Alabi",
    "version": (0, 1, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar (N) > Forge",
    "description": "Local socket bridge that exposes Blender to the Forge MCP server",
    "category": "Interface",
}

import base64
import json
import math
import os
import queue
import socket
import tempfile
import threading
import traceback
from io import StringIO
from contextlib import redirect_stdout

import bmesh
import bpy
from mathutils import Euler, Vector

HOST = "127.0.0.1"
DEFAULT_PORT = 9876
_SERVER = {"obj": None}
_CHECKPOINTS = {}


# ---------------------------------------------------------------- transport


class ForgeBridge:
    """Accepts newline-delimited JSON commands and hands them to the main thread."""

    def __init__(self, port=DEFAULT_PORT):
        self.port = port
        self.running = False
        self._sock = None
        self._thread = None
        self.inbox = queue.Queue()

    def start(self):
        if self.running:
            return
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((HOST, self.port))
        self._sock.listen(4)
        self._sock.settimeout(0.5)
        self.running = True
        self._thread = threading.Thread(target=self._accept_loop, daemon=True)
        self._thread.start()
        print(f"[forge] listening on {HOST}:{self.port}")

    def stop(self):
        self.running = False
        if self._sock:
            try:
                self._sock.close()
            except Exception:
                pass
        self._sock = None
        print("[forge] stopped")

    def _accept_loop(self):
        while self.running:
            try:
                conn, _ = self._sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._client_loop, args=(conn,), daemon=True).start()

    def _client_loop(self, conn):
        conn.settimeout(None)
        buf = b""
        with conn:
            while self.running:
                try:
                    chunk = conn.recv(65536)
                except OSError:
                    break
                if not chunk:
                    break
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    if not line.strip():
                        continue
                    reply = self._run_on_main(line)
                    try:
                        conn.sendall(json.dumps(reply).encode() + b"\n")
                    except OSError:
                        return

    def _run_on_main(self, line):
        try:
            payload = json.loads(line.decode())
        except Exception as exc:
            return {"ok": False, "error": f"bad JSON: {exc}"}
        out = queue.Queue()
        self.inbox.put((payload, out))
        try:
            # Renders can be slow; give them room.
            return out.get(timeout=600)
        except queue.Empty:
            return {"ok": False, "error": "timed out waiting for Blender main thread"}


@bpy.app.handlers.persistent
def _pump():
    """Drains the command queue on Blender's main thread. bpy is not thread-safe."""
    bridge = _SERVER["obj"]
    if bridge and bridge.running:
        while True:
            try:
                payload, out = bridge.inbox.get_nowait()
            except queue.Empty:
                break
            try:
                if bpy.context.mode != "OBJECT":
                    try:
                        bpy.ops.object.mode_set(mode="OBJECT")
                    except Exception:
                        pass
                result = dispatch(payload)
                out.put({"ok": True, "result": result})
            except Exception as exc:
                out.put(
                    {
                        "ok": False,
                        "error": f"{type(exc).__name__}: {exc}",
                        "trace": traceback.format_exc()[-2000:],
                    }
                )
    return 0.05


# ----------------------------------------------------------------- helpers


def _obj(name):
    ob = bpy.data.objects.get(name)
    if ob is None:
        raise ValueError(f"no object named {name!r} (have: {sorted(bpy.data.objects.keys())[:40]})")
    return ob


def _activate(ob):
    for o in bpy.context.selected_objects:
        o.select_set(False)
    ob.select_set(True)
    bpy.context.view_layer.objects.active = ob
    return ob


def _summarize(ob):
    d = {
        "name": ob.name,
        "type": ob.type,
        "location": [round(v, 4) for v in ob.location],
        "rotation_euler": [round(math.degrees(v), 2) for v in ob.rotation_euler],
        "scale": [round(v, 4) for v in ob.scale],
        "modifiers": [{"name": m.name, "type": m.type} for m in ob.modifiers],
        "materials": [m.name for m in ob.data.materials] if getattr(ob.data, "materials", None) else [],
    }
    if ob.type == "MESH":
        d["verts"] = len(ob.data.vertices)
        d["faces"] = len(ob.data.polygons)
        bb = [ob.matrix_world @ Vector(c) for c in ob.bound_box]
        lo = Vector((min(v.x for v in bb), min(v.y for v in bb), min(v.z for v in bb)))
        hi = Vector((max(v.x for v in bb), max(v.y for v in bb), max(v.z for v in bb)))
        d["world_bounds"] = {"min": [round(v, 3) for v in lo], "max": [round(v, 3) for v in hi]}
    return d


def _scene_bounds():
    pts = []
    for ob in bpy.context.scene.objects:
        if ob.type == "MESH" and ob.visible_get():
            pts += [ob.matrix_world @ Vector(c) for c in ob.bound_box]
    if not pts:
        return Vector((0, 0, 0)), 5.0
    lo = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
    hi = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
    center = (lo + hi) / 2
    radius = max((hi - lo).length / 2, 0.5)
    return center, radius


def _look_at(ob, target):
    direction = Vector(target) - ob.location
    ob.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()


def _resolve_engine(preferred):
    """Engine enum names move between Blender versions; pick whatever exists."""
    available = list(bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items.keys())
    order = {
        "eevee": ["BLENDER_EEVEE_NEXT", "BLENDER_EEVEE"],
        "cycles": ["CYCLES"],
        "workbench": ["BLENDER_WORKBENCH"],
    }.get((preferred or "eevee").lower(), [preferred])
    for candidate in order:
        if candidate in available:
            return candidate
    return available[0]


def _set_props(target, params, label):
    """Generic property setter that resolves object-name strings to real objects."""
    warnings = []
    for key, value in (params or {}).items():
        if not hasattr(target, key):
            warnings.append(f"{label} has no property {key!r}")
            continue
        current = getattr(target, key)
        if isinstance(value, str) and not isinstance(current, str) and value in bpy.data.objects:
            value = bpy.data.objects[value]
        try:
            setattr(target, key, value)
        except Exception as exc:
            warnings.append(f"could not set {key}={value!r}: {exc}")
    return warnings


# ---------------------------------------------------------------- selection


def _select_faces(bm, spec):
    """spec: 'all' | {'indices': [...]} | {'axis': '+Z', 'threshold': 0.5} | {'above_z': 1.0}"""
    faces = list(bm.faces)
    if spec in (None, "all"):
        return faces
    if isinstance(spec, list):
        return [f for f in faces if f.index in set(spec)]
    if isinstance(spec, dict):
        if "indices" in spec:
            keep = set(spec["indices"])
            return [f for f in faces if f.index in keep]
        if "axis" in spec:
            axis = spec["axis"].upper()
            sign = -1.0 if axis.startswith("-") else 1.0
            letter = axis[-1]
            vec = Vector({"X": (1, 0, 0), "Y": (0, 1, 0), "Z": (0, 0, 1)}[letter]) * sign
            thr = float(spec.get("threshold", 0.5))
            return [f for f in faces if f.normal.normalized().dot(vec) > thr]
        if "above_z" in spec:
            z = float(spec["above_z"])
            return [f for f in faces if f.calc_center_median().z > z]
        if "below_z" in spec:
            z = float(spec["below_z"])
            return [f for f in faces if f.calc_center_median().z < z]
        if "largest" in spec:
            n = int(spec["largest"])
            return sorted(faces, key=lambda f: f.calc_area(), reverse=True)[:n]
    raise ValueError(f"unrecognized face selector: {spec!r}")


# ---------------------------------------------------------------- handlers


def h_ping(**_):
    return {"blender": bpy.app.version_string, "scene": bpy.context.scene.name}


def h_get_scene(**_):
    scene = bpy.context.scene
    center, radius = _scene_bounds()
    return {
        "scene": scene.name,
        "frame": scene.frame_current,
        "engine": scene.render.engine,
        "object_count": len(scene.objects),
        "objects": [_summarize(o) for o in scene.objects][:200],
        "materials": [m.name for m in bpy.data.materials],
        "bounds_center": [round(v, 3) for v in center],
        "bounds_radius": round(radius, 3),
    }


def h_inspect_object(name, **_):
    return _summarize(_obj(name))


PRIMITIVES = {
    "cube": ("primitive_cube_add", {"size"}),
    "plane": ("primitive_plane_add", {"size"}),
    "sphere": ("primitive_uv_sphere_add", {"radius", "segments", "ring_count"}),
    "icosphere": ("primitive_ico_sphere_add", {"radius", "subdivisions"}),
    "cylinder": ("primitive_cylinder_add", {"radius", "depth", "vertices"}),
    "cone": ("primitive_cone_add", {"radius1", "radius2", "depth", "vertices"}),
    "torus": ("primitive_torus_add", {"major_radius", "minor_radius", "major_segments", "minor_segments"}),
    "circle": ("primitive_circle_add", {"radius", "vertices", "fill_type"}),
    "grid": ("primitive_grid_add", {"size", "x_subdivisions", "y_subdivisions"}),
    "monkey": ("primitive_monkey_add", {"size"}),
}


def h_create_primitive(kind, name=None, location=(0, 0, 0), rotation=(0, 0, 0), scale=(1, 1, 1), params=None, **_):
    kind = kind.lower()
    if kind not in PRIMITIVES:
        raise ValueError(f"unknown primitive {kind!r}; options: {sorted(PRIMITIVES)}")
    op_name, allowed = PRIMITIVES[kind]
    kwargs = {k: v for k, v in (params or {}).items() if k in allowed}
    kwargs["location"] = tuple(location)
    kwargs["rotation"] = tuple(math.radians(a) for a in rotation)
    getattr(bpy.ops.mesh, op_name)(**kwargs)
    ob = bpy.context.active_object
    if name:
        ob.name = name
    ob.scale = tuple(scale)
    return _summarize(ob)


def h_transform_object(name, location=None, rotation=None, scale=None, relative=False, **_):
    ob = _obj(name)
    if location is not None:
        ob.location = Vector(ob.location) + Vector(location) if relative else Vector(location)
    if rotation is not None:
        rad = [math.radians(a) for a in rotation]
        if relative:
            ob.rotation_euler = Euler([a + b for a, b in zip(ob.rotation_euler, rad)])
        else:
            ob.rotation_euler = Euler(rad)
    if scale is not None:
        ob.scale = [a * b for a, b in zip(ob.scale, scale)] if relative else Vector(scale)
    bpy.context.view_layer.update()
    return _summarize(ob)


def h_duplicate_object(name, new_name=None, location=None, rotation=None, scale=None, linked=False, count=1, **_):
    src = _obj(name)
    made = []
    for i in range(max(1, int(count))):
        copy = src.copy()
        if not linked and src.data:
            copy.data = src.data.copy()
        bpy.context.collection.objects.link(copy)
        if new_name:
            copy.name = new_name if count == 1 else f"{new_name}.{i:03d}"
        if location is not None:
            copy.location = Vector(src.location) + Vector(location) * (i + 1)
        if rotation is not None:
            copy.rotation_euler = Euler([math.radians(a) * (i + 1) for a in rotation])
        if scale is not None:
            copy.scale = Vector(scale)
        made.append(_summarize(copy))
    return {"created": made}


def h_delete_object(name, **_):
    names = [name] if isinstance(name, str) else list(name)
    for n in names:
        ob = bpy.data.objects.get(n)
        if ob:
            bpy.data.objects.remove(ob, do_unlink=True)
    return {"deleted": names}


def h_clear_scene(keep_lights=False, keep_camera=True, **_):
    removed = []
    for ob in list(bpy.context.scene.objects):
        if ob.type == "CAMERA" and keep_camera:
            continue
        if ob.type == "LIGHT" and keep_lights:
            continue
        removed.append(ob.name)
        bpy.data.objects.remove(ob, do_unlink=True)
    return {"removed": removed}


def h_edit_mesh(name, op, select="all", params=None, **_):
    ob = _obj(name)
    if ob.type != "MESH":
        raise ValueError(f"{name!r} is a {ob.type}, not a MESH")
    p = params or {}
    bm = bmesh.new()
    bm.from_mesh(ob.data)
    bm.faces.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.verts.ensure_lookup_table()
    faces = _select_faces(bm, select)
    if not faces and op != "triangulate":
        bm.free()
        raise ValueError("selector matched no faces")

    op = op.lower()
    if op == "extrude":
        amount = float(p.get("amount", 1.0))
        normal = Vector((0, 0, 0))
        for f in faces:
            normal += f.normal
        normal = normal.normalized() if normal.length > 1e-6 else Vector((0, 0, 1))
        vec = Vector(p["vector"]) if "vector" in p else normal * amount
        ret = bmesh.ops.extrude_face_region(bm, geom=faces)
        new_verts = [g for g in ret["geom"] if isinstance(g, bmesh.types.BMVert)]
        bmesh.ops.translate(bm, verts=new_verts, vec=vec)
        bmesh.ops.delete(bm, geom=faces, context="FACES")
    elif op == "inset":
        bmesh.ops.inset_region(
            bm,
            faces=faces,
            thickness=float(p.get("thickness", 0.1)),
            depth=float(p.get("depth", 0.0)),
            use_even_offset=True,
            use_individual=bool(p.get("individual", False)),
        )
    elif op == "bevel":
        edges = {e for f in faces for e in f.edges}
        bmesh.ops.bevel(
            bm,
            geom=list(edges),
            offset=float(p.get("offset", 0.05)),
            segments=int(p.get("segments", 2)),
            profile=float(p.get("profile", 0.5)),
            affect="EDGES",
            clamp_overlap=True,
        )
    elif op == "subdivide":
        edges = {e for f in faces for e in f.edges}
        bmesh.ops.subdivide_edges(bm, edges=list(edges), cuts=int(p.get("cuts", 1)), use_grid_fill=True)
    elif op == "poke":
        bmesh.ops.poke(bm, faces=faces)
    elif op == "triangulate":
        bmesh.ops.triangulate(bm, faces=faces or list(bm.faces))
    elif op == "translate_faces":
        verts = {v for f in faces for v in f.verts}
        bmesh.ops.translate(bm, verts=list(verts), vec=Vector(p.get("vector", (0, 0, 1))))
    elif op == "scale_faces":
        verts = list({v for f in faces for v in f.verts})
        center = sum((v.co for v in verts), Vector()) / len(verts)
        factor = p.get("factor", 1.1)
        factor = Vector((factor, factor, factor)) if isinstance(factor, (int, float)) else Vector(factor)
        for v in verts:
            v.co = center + Vector(((v.co - center)[i] * factor[i] for i in range(3)))
    elif op == "delete_faces":
        bmesh.ops.delete(bm, geom=faces, context="FACES")
    else:
        bm.free()
        raise ValueError(
            "unknown op; options: extrude, inset, bevel, subdivide, poke, triangulate, "
            "translate_faces, scale_faces, delete_faces"
        )

    bm.normal_update()
    bm.to_mesh(ob.data)
    bm.free()
    ob.data.update()
    return _summarize(ob)


def h_add_modifier(name, type, modifier_name=None, params=None, **_):
    ob = _obj(name)
    mod = ob.modifiers.new(name=modifier_name or type.title(), type=type.upper())
    warnings = _set_props(mod, params, f"{type} modifier")
    settable = [p.identifier for p in mod.bl_rna.properties if not p.is_readonly][:60]
    return {"object": ob.name, "modifier": mod.name, "warnings": warnings, "settable_properties": settable}


def h_apply_modifier(name, modifier_name=None, **_):
    ob = _activate(_obj(name))
    targets = [modifier_name] if modifier_name else [m.name for m in ob.modifiers]
    for m in targets:
        bpy.ops.object.modifier_apply(modifier=m)
    return _summarize(ob)


def h_boolean(target, cutter, operation="DIFFERENCE", apply=True, delete_cutter=True, solver="EXACT", **_):
    tgt, cut = _obj(target), _obj(cutter)
    mod = tgt.modifiers.new(name="ForgeBoolean", type="BOOLEAN")
    mod.operation = operation.upper()
    mod.object = cut
    try:
        mod.solver = solver.upper()
    except Exception:
        pass
    if apply:
        _activate(tgt)
        bpy.ops.object.modifier_apply(modifier=mod.name)
        if delete_cutter:
            bpy.data.objects.remove(cut, do_unlink=True)
    return _summarize(tgt)


def h_create_material(
    name,
    base_color=(0.8, 0.8, 0.8, 1.0),
    metallic=0.0,
    roughness=0.5,
    emission_color=None,
    emission_strength=0.0,
    alpha=1.0,
    transmission=0.0,
    ior=1.45,
    **_,
):
    mat = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf is None:
        bsdf = mat.node_tree.nodes.new("ShaderNodeBsdfPrincipled")
        out = mat.node_tree.nodes.get("Material Output") or mat.node_tree.nodes.new("ShaderNodeOutputMaterial")
        mat.node_tree.links.new(bsdf.outputs[0], out.inputs[0])
    color = list(base_color) + [1.0] * (4 - len(base_color))

    def put(socket_name, value):
        sock = bsdf.inputs.get(socket_name)
        if sock is not None and value is not None:
            sock.default_value = value

    put("Base Color", color)
    put("Metallic", float(metallic))
    put("Roughness", float(roughness))
    put("Alpha", float(alpha))
    put("IOR", float(ior))
    put("Transmission Weight", float(transmission))
    if emission_color is not None:
        put("Emission Color", list(emission_color) + [1.0] * (4 - len(emission_color)))
    put("Emission Strength", float(emission_strength))
    if alpha < 1.0 or transmission > 0:
        mat.blend_method = "BLEND" if hasattr(mat, "blend_method") else mat.blend_method
    return {"material": mat.name}


def h_assign_material(name, material, slot=None, **_):
    ob = _obj(name)
    mat = bpy.data.materials.get(material)
    if mat is None:
        raise ValueError(f"no material named {material!r}")
    if slot is None:
        if ob.data.materials:
            ob.data.materials[0] = mat
        else:
            ob.data.materials.append(mat)
    else:
        while len(ob.data.materials) <= slot:
            ob.data.materials.append(None)
        ob.data.materials[slot] = mat
    return _summarize(ob)


def h_add_light(type="AREA", name=None, location=(4, -4, 6), energy=1000.0, color=(1, 1, 1), size=2.0, look_at=None, **_):
    data = bpy.data.lights.new(name=name or f"Light_{type}", type=type.upper())
    data.energy = float(energy)
    data.color = tuple(color)[:3]
    if hasattr(data, "size"):
        data.size = float(size)
    if type.upper() == "SUN" and hasattr(data, "angle"):
        data.angle = math.radians(float(size))
    ob = bpy.data.objects.new(name or data.name, data)
    bpy.context.collection.objects.link(ob)
    ob.location = tuple(location)
    _look_at(ob, look_at if look_at is not None else _scene_bounds()[0])
    return _summarize(ob)


def h_setup_camera(location=None, look_at=None, focal_length=50.0, name="Camera", frame_all=True, **_):
    cam = bpy.data.objects.get(name)
    if cam is None or cam.type != "CAMERA":
        data = bpy.data.cameras.new(name)
        cam = bpy.data.objects.new(name, data)
        bpy.context.collection.objects.link(cam)
    cam.data.lens = float(focal_length)
    center, radius = _scene_bounds()
    target = Vector(look_at) if look_at is not None else center
    if location is not None:
        cam.location = Vector(location)
    elif frame_all:
        offset = Vector((1.0, -1.6, 0.8)).normalized() * (radius * 3.2)
        cam.location = center + offset
    _look_at(cam, target)
    bpy.context.scene.camera = cam
    return _summarize(cam)


def h_set_world(color=(0.05, 0.05, 0.06), strength=1.0, **_):
    world = bpy.context.scene.world or bpy.data.worlds.new("World")
    bpy.context.scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    if bg:
        bg.inputs[0].default_value = list(color) + [1.0] * (4 - len(color))
        bg.inputs[1].default_value = float(strength)
    return {"world": world.name}


def h_render(width=640, height=480, samples=32, engine="eevee", mode="render", transparent=False, **_):
    scene = bpy.context.scene
    if scene.camera is None:
        h_setup_camera()
    scene.render.engine = _resolve_engine(engine)
    scene.render.resolution_x = int(width)
    scene.render.resolution_y = int(height)
    scene.render.resolution_percentage = 100
    scene.render.film_transparent = bool(transparent)
    scene.render.image_settings.file_format = "PNG"
    try:
        if scene.render.engine == "CYCLES":
            scene.cycles.samples = int(samples)
        else:
            scene.eevee.taa_render_samples = int(samples)
    except Exception:
        pass

    path = os.path.join(tempfile.gettempdir(), f"forge_render_{os.getpid()}.png")
    scene.render.filepath = path
    if mode == "viewport":
        bpy.ops.render.opengl(write_still=True, view_context=False)
    else:
        bpy.ops.render.render(write_still=True)
    with open(path, "rb") as fh:
        blob = fh.read()
    return {
        "image_b64": base64.b64encode(blob).decode(),
        "width": int(width),
        "height": int(height),
        "engine": scene.render.engine,
        "bytes": len(blob),
    }


def h_run_python(code, **_):
    ns = {"bpy": bpy, "bmesh": bmesh, "math": math, "Vector": Vector, "Euler": Euler}
    out = StringIO()
    with redirect_stdout(out):
        exec(code, ns)
    return {"stdout": out.getvalue()[-8000:], "result": repr(ns.get("result"))[:4000] if "result" in ns else None}


def h_checkpoint(label="default", **_):
    _CHECKPOINTS[label] = {
        "objects": set(bpy.data.objects.keys()),
        "materials": set(bpy.data.materials.keys()),
    }
    return {"label": label, "objects": len(_CHECKPOINTS[label]["objects"])}


def h_rollback(label="default", **_):
    snap = _CHECKPOINTS.get(label)
    if snap is None:
        raise ValueError(f"no checkpoint named {label!r}")
    removed = []
    for n in list(bpy.data.objects.keys()):
        if n not in snap["objects"]:
            bpy.data.objects.remove(bpy.data.objects[n], do_unlink=True)
            removed.append(n)
    for n in list(bpy.data.materials.keys()):
        if n not in snap["materials"]:
            bpy.data.materials.remove(bpy.data.materials[n])
    return {"label": label, "removed": removed}


def h_save_file(filepath, **_):
    bpy.ops.wm.save_as_mainfile(filepath=os.path.expanduser(filepath), copy=True)
    return {"saved": os.path.expanduser(filepath)}


HANDLERS = {
    "ping": h_ping,
    "get_scene": h_get_scene,
    "inspect_object": h_inspect_object,
    "create_primitive": h_create_primitive,
    "transform_object": h_transform_object,
    "duplicate_object": h_duplicate_object,
    "delete_object": h_delete_object,
    "clear_scene": h_clear_scene,
    "edit_mesh": h_edit_mesh,
    "add_modifier": h_add_modifier,
    "apply_modifier": h_apply_modifier,
    "boolean": h_boolean,
    "create_material": h_create_material,
    "assign_material": h_assign_material,
    "add_light": h_add_light,
    "setup_camera": h_setup_camera,
    "set_world": h_set_world,
    "render": h_render,
    "run_python": h_run_python,
    "checkpoint": h_checkpoint,
    "rollback": h_rollback,
    "save_file": h_save_file,
}


def dispatch(payload):
    cmd = payload.get("command")
    handler = HANDLERS.get(cmd)
    if handler is None:
        raise ValueError(f"unknown command {cmd!r}; known: {sorted(HANDLERS)}")
    return handler(**(payload.get("params") or {}))


# ---------------------------------------------------------------------- UI


class FORGE_OT_start(bpy.types.Operator):
    bl_idname = "forge.start"
    bl_label = "Start Forge Bridge"

    def execute(self, context):
        if _SERVER["obj"] is None:
            _SERVER["obj"] = ForgeBridge(context.scene.forge_port)
        _SERVER["obj"].port = context.scene.forge_port
        _SERVER["obj"].start()
        if not bpy.app.timers.is_registered(_pump):
            bpy.app.timers.register(_pump, persistent=True)
        context.scene.forge_running = True
        return {"FINISHED"}


class FORGE_OT_stop(bpy.types.Operator):
    bl_idname = "forge.stop"
    bl_label = "Stop Forge Bridge"

    def execute(self, context):
        if _SERVER["obj"]:
            _SERVER["obj"].stop()
        context.scene.forge_running = False
        return {"FINISHED"}


class FORGE_PT_panel(bpy.types.Panel):
    bl_label = "Forge MCP"
    bl_idname = "FORGE_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Forge"

    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene, "forge_port")
        if context.scene.forge_running:
            layout.label(text=f"Listening on {HOST}:{context.scene.forge_port}", icon="CHECKMARK")
            layout.operator("forge.stop", icon="PAUSE")
        else:
            layout.operator("forge.start", icon="PLAY")
        layout.separator()
        layout.label(text="Executes model-generated code.", icon="ERROR")


CLASSES = (FORGE_OT_start, FORGE_OT_stop, FORGE_PT_panel)


def register():
    bpy.types.Scene.forge_port = bpy.props.IntProperty(name="Port", default=DEFAULT_PORT, min=1024, max=65535)
    bpy.types.Scene.forge_running = bpy.props.BoolProperty(default=False)
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    if _SERVER["obj"]:
        _SERVER["obj"].stop()
    if bpy.app.timers.is_registered(_pump):
        bpy.app.timers.unregister(_pump)
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.forge_port
    del bpy.types.Scene.forge_running


if __name__ == "__main__":
    register()
