"""Forge — an MCP server for generative 3D modeling in Blender.

Talks to the Forge add-on running inside Blender over a local socket. Every tool
is a thin, typed wrapper; the modeling intelligence lives in the calling model,
and `render_view` closes the loop by handing that model an actual image back.
"""

from __future__ import annotations

import base64
import json
import os
import socket
import threading
from typing import Any, Literal

try:  # MCP SDK >= 2.0
    from mcp.server.mcpserver import Image, MCPServer as _Server
except ImportError:  # MCP SDK 1.x
    from mcp.server.fastmcp import FastMCP as _Server, Image  # type: ignore[no-redef]

HOST = os.environ.get("FORGE_BLENDER_HOST", "127.0.0.1")
PORT = int(os.environ.get("FORGE_BLENDER_PORT", "9876"))
TIMEOUT = float(os.environ.get("FORGE_TIMEOUT", "600"))

mcp = _Server("forge")


class Bridge:
    """One persistent socket to Blender, serialized behind a lock."""

    def __init__(self) -> None:
        self._sock: socket.socket | None = None
        self._buf = b""
        self._lock = threading.Lock()

    def _connect(self) -> socket.socket:
        if self._sock is not None:
            return self._sock
        try:
            sock = socket.create_connection((HOST, PORT), timeout=10)
        except OSError as exc:
            raise RuntimeError(
                f"Cannot reach Blender on {HOST}:{PORT} ({exc}). "
                "Open Blender, press N in the 3D viewport, go to the Forge tab, and click Start."
            ) from exc
        sock.settimeout(TIMEOUT)
        self._sock = sock
        self._buf = b""
        return sock

    def _drop(self) -> None:
        if self._sock:
            try:
                self._sock.close()
            except OSError:
                pass
        self._sock = None
        self._buf = b""

    def call(self, command: str, **params: Any) -> dict:
        payload = json.dumps({"command": command, "params": params}).encode() + b"\n"
        with self._lock:
            for attempt in (1, 2):
                try:
                    sock = self._connect()
                    sock.sendall(payload)
                    while b"\n" not in self._buf:
                        chunk = sock.recv(1 << 20)
                        if not chunk:
                            raise ConnectionError("Blender closed the connection")
                        self._buf += chunk
                    line, self._buf = self._buf.split(b"\n", 1)
                    break
                except (OSError, ConnectionError):
                    self._drop()
                    if attempt == 2:
                        raise RuntimeError("Lost connection to Blender. Is the Forge bridge still running?")
        reply = json.loads(line.decode())
        if not reply.get("ok"):
            raise RuntimeError(reply.get("error", "unknown Blender error"))
        return reply.get("result") or {}


bridge = Bridge()


# ------------------------------------------------------------------ inspect


@mcp.tool()
def get_scene() -> dict:
    """List every object in the current Blender scene with transforms, poly counts,
    world-space bounds, modifiers and materials. Call this first, and again whenever
    you have lost track of what exists."""
    return bridge.call("get_scene")


@mcp.tool()
def inspect_object(name: str) -> dict:
    """Detailed state of one object: transform, vert/face counts, world bounds,
    modifier stack, material slots."""
    return bridge.call("inspect_object", name=name)


# ------------------------------------------------------------------ create


@mcp.tool()
def create_primitive(
    kind: Literal[
        "cube", "plane", "sphere", "icosphere", "cylinder", "cone",
        "torus", "circle", "grid", "monkey",
    ],
    name: str | None = None,
    location: list[float] = [0, 0, 0],
    rotation: list[float] = [0, 0, 0],
    scale: list[float] = [1, 1, 1],
    params: dict | None = None,
) -> dict:
    """Add a mesh primitive. Rotation is in degrees.

    `params` takes primitive-specific options: size (cube/plane/grid/monkey);
    radius, segments, ring_count (sphere); radius, subdivisions (icosphere);
    radius, depth, vertices (cylinder); radius1, radius2, depth, vertices (cone);
    major_radius, minor_radius, major_segments, minor_segments (torus);
    x_subdivisions, y_subdivisions (grid).
    """
    return bridge.call(
        "create_primitive",
        kind=kind, name=name, location=location,
        rotation=rotation, scale=scale, params=params or {},
    )


@mcp.tool()
def transform_object(
    name: str,
    location: list[float] | None = None,
    rotation: list[float] | None = None,
    scale: list[float] | None = None,
    relative: bool = False,
) -> dict:
    """Move, rotate (degrees) or scale an object. With relative=True the values are
    added to (or multiplied into) the current transform instead of replacing it."""
    return bridge.call(
        "transform_object", name=name, location=location,
        rotation=rotation, scale=scale, relative=relative,
    )


@mcp.tool()
def duplicate_object(
    name: str,
    new_name: str | None = None,
    count: int = 1,
    offset: list[float] | None = None,
    rotation_step: list[float] | None = None,
    scale: list[float] | None = None,
    linked: bool = False,
) -> dict:
    """Copy an object one or more times. `offset` and `rotation_step` accumulate per
    copy, so count=6 with rotation_step=[0,0,60] gives a radial ring. Use linked=True
    for instances that share mesh data (cheap for scattering)."""
    return bridge.call(
        "duplicate_object", name=name, new_name=new_name, count=count,
        location=offset, rotation=rotation_step, scale=scale, linked=linked,
    )


@mcp.tool()
def delete_object(name: str | list[str]) -> dict:
    """Delete one object or a list of objects by name."""
    return bridge.call("delete_object", name=name)


@mcp.tool()
def clear_scene(keep_camera: bool = True, keep_lights: bool = False) -> dict:
    """Wipe the scene. Use before starting a fresh model rather than piling new
    geometry on top of old."""
    return bridge.call("clear_scene", keep_camera=keep_camera, keep_lights=keep_lights)


# -------------------------------------------------------------------- shape


@mcp.tool()
def edit_mesh(
    name: str,
    op: Literal[
        "extrude", "inset", "bevel", "subdivide", "poke", "triangulate",
        "translate_faces", "scale_faces", "delete_faces",
    ],
    select: Any = "all",
    params: dict | None = None,
) -> dict:
    """Run a bmesh operation on a subset of an object's faces — this is how you get
    shapes that primitives and modifiers cannot give you.

    `select` is one of:
      "all"
      {"axis": "+Z", "threshold": 0.5}   faces whose normal points that way
      {"above_z": 1.2} / {"below_z": 0}  faces by height
      {"largest": 3}                     the N biggest faces
      {"indices": [0, 4, 9]}             explicit face indices

    `params` by op:
      extrude          amount (along averaged normal) or vector [x,y,z]
      inset            thickness, depth, individual
      bevel            offset, segments, profile
      subdivide        cuts
      translate_faces  vector
      scale_faces      factor (number or [x,y,z])
    """
    return bridge.call("edit_mesh", name=name, op=op, select=select, params=params or {})


@mcp.tool()
def add_modifier(
    name: str,
    type: str,
    modifier_name: str | None = None,
    params: dict | None = None,
) -> dict:
    """Add a modifier — SUBSURF, BEVEL, ARRAY, MIRROR, SOLIDIFY, SCREW, REMESH,
    DECIMATE, DISPLACE, CURVE, SIMPLE_DEFORM, WELD, WIREFRAME, etc.

    `params` sets properties directly (e.g. {"levels": 2, "render_levels": 3} for
    SUBSURF, {"count": 5, "relative_offset_displace": [1.2, 0, 0]} for ARRAY). Any
    value naming an existing object is resolved to that object, so
    {"mirror_object": "Axis"} works. The response lists every settable property on
    the modifier, so read it if a parameter did not take.
    """
    return bridge.call("add_modifier", name=name, type=type, modifier_name=modifier_name, params=params or {})


@mcp.tool()
def apply_modifier(name: str, modifier_name: str | None = None) -> dict:
    """Bake modifiers into real geometry. Omit modifier_name to apply the whole stack.
    Do this before booleans, and before exporting."""
    return bridge.call("apply_modifier", name=name, modifier_name=modifier_name)


@mcp.tool()
def boolean(
    target: str,
    cutter: str,
    operation: Literal["DIFFERENCE", "UNION", "INTERSECT"] = "DIFFERENCE",
    apply: bool = True,
    delete_cutter: bool = True,
) -> dict:
    """Cut, fuse or intersect one object with another. The cutter is consumed by
    default. Booleans are cleaner when both meshes are manifold and modifiers on the
    target have already been applied."""
    return bridge.call(
        "boolean", target=target, cutter=cutter, operation=operation,
        apply=apply, delete_cutter=delete_cutter,
    )


# ------------------------------------------------------------------- shade


@mcp.tool()
def create_material(
    name: str,
    base_color: list[float] = [0.8, 0.8, 0.8, 1.0],
    metallic: float = 0.0,
    roughness: float = 0.5,
    emission_color: list[float] | None = None,
    emission_strength: float = 0.0,
    alpha: float = 1.0,
    transmission: float = 0.0,
    ior: float = 1.45,
) -> dict:
    """Create or update a Principled BSDF material. Colors are linear RGB 0-1.
    Rough guide: metal = metallic 1.0 / roughness 0.2-0.4; plastic = metallic 0 /
    roughness 0.3; glass = transmission 1.0 / roughness 0."""
    return bridge.call(
        "create_material", name=name, base_color=base_color, metallic=metallic,
        roughness=roughness, emission_color=emission_color,
        emission_strength=emission_strength, alpha=alpha,
        transmission=transmission, ior=ior,
    )


@mcp.tool()
def assign_material(name: str, material: str, slot: int | None = None) -> dict:
    """Attach an existing material to an object, optionally in a specific slot."""
    return bridge.call("assign_material", name=name, material=material, slot=slot)


@mcp.tool()
def add_light(
    type: Literal["AREA", "POINT", "SUN", "SPOT"] = "AREA",
    name: str | None = None,
    location: list[float] = [4, -4, 6],
    energy: float = 1000.0,
    color: list[float] = [1, 1, 1],
    size: float = 2.0,
    look_at: list[float] | None = None,
) -> dict:
    """Add a light aimed at the scene centre (or at `look_at`). AREA lights want
    energy in the hundreds-to-thousands; SUN wants roughly 1-10, and `size` becomes
    its angular diameter in degrees."""
    return bridge.call(
        "add_light", type=type, name=name, location=location,
        energy=energy, color=color, size=size, look_at=look_at,
    )


@mcp.tool()
def setup_camera(
    location: list[float] | None = None,
    look_at: list[float] | None = None,
    focal_length: float = 50.0,
    frame_all: bool = True,
) -> dict:
    """Place the scene camera. With no location and frame_all=True it computes a
    three-quarter view that fits the whole scene — call it again after the model
    grows so the render still frames everything."""
    return bridge.call(
        "setup_camera", location=location, look_at=look_at,
        focal_length=focal_length, frame_all=frame_all,
    )


@mcp.tool()
def set_world(color: list[float] = [0.05, 0.05, 0.06], strength: float = 1.0) -> dict:
    """Set the world background color and strength. Raising strength gives cheap
    ambient fill and stops unlit sides going pure black."""
    return bridge.call("set_world", color=color, strength=strength)


# ------------------------------------------------------------------ feedback


@mcp.tool()
def render_view(
    width: int = 640,
    height: int = 480,
    samples: int = 32,
    engine: Literal["eevee", "cycles", "workbench"] = "eevee",
    mode: Literal["render", "viewport"] = "render",
    transparent: bool = False,
) -> Image:
    """Render the scene camera and return the image, so you can actually look at what
    you built before deciding what to change.

    Use this constantly — after blocking out forms, after booleans, before declaring
    anything finished. mode="viewport" is a fast unlit preview for checking silhouette
    and proportion; the default render shows materials and lighting. Keep width and
    height small while iterating.
    """
    result = bridge.call(
        "render", width=width, height=height, samples=samples,
        engine=engine, mode=mode, transparent=transparent,
    )
    return Image(data=base64.b64decode(result["image_b64"]), format="png")


# --------------------------------------------------------------- iteration


@mcp.tool()
def checkpoint(label: str = "default") -> dict:
    """Record which objects and materials currently exist, so a failed experiment can
    be undone. Take one before any risky sequence."""
    return bridge.call("checkpoint", label=label)


@mcp.tool()
def rollback(label: str = "default") -> dict:
    """Delete every object and material created since that checkpoint. Note this
    removes new datablocks — it does not restore edits made to objects that already
    existed at checkpoint time."""
    return bridge.call("rollback", label=label)


@mcp.tool()
def run_python(code: str) -> dict:
    """Execute Python inside Blender with bpy, bmesh, math, Vector and Euler in scope.
    The escape hatch for anything the typed tools do not cover — curves, geometry
    nodes, particle systems, UVs, animation. Assign to a variable named `result` to
    return a value; print() output is captured."""
    return bridge.call("run_python", code=code)


@mcp.tool()
def save_file(filepath: str) -> dict:
    """Save a copy of the current .blend to an absolute path."""
    return bridge.call("save_file", filepath=filepath)


# ----------------------------------------------------------------- prompts


@mcp.prompt()
def model(subject: str) -> str:
    """Guided workflow for building a subject from scratch."""
    return f"""Model: {subject}

Work in this order, and render often — you cannot model well without looking.

1. clear_scene, then set up a camera and at least two lights (key + fill) and a
   world strength around 1.0 so nothing reads as pure black.
2. Block out the major masses with primitives at correct relative proportions.
   render_view with mode="viewport" and judge the silhouette before adding detail.
3. Refine per part: edit_mesh for extrusions and insets, modifiers for repetition,
   bevel and subsurf for surface quality. checkpoint before anything destructive.
4. Materials last. Keep the palette small and check roughness under the real render.
5. Final render at higher resolution and samples. Compare against the intent, name
   what is still wrong, and fix it rather than declaring it done.

Do not narrate every tool call. Do inspect the render and say what you actually see.
"""


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
